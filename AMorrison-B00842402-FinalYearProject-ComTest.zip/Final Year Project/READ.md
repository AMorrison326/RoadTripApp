# Final Year Project: Trip Planner App

This Android application helps users create and manage trips by allowing them to set start and destination locations, add stops, calculate estimated fuel costs. It also aids to organize packing, cost budgeting and with entertainment.

## Features
- Firebase Authentication: Used to secure user sign-in and sign-out.
- Google Places Autocomplete: An intuitive start/destination selection and stop additions.
- Trip Creation: Add name, dates, passengers by age group, and route details.
- Navigation Integration: Export trips directly to Google Maps with all stops.
- Packing List: Manage items to pack for each trip.
- Entertainment Page: Access curated travel-related audio content.
- Fuel Cost Estimation: Uses user profile info (MPG & fuel price per litre) for basic cost prediction.
- User Profile: Store vehicle type, fuel details, route preference, and more.
- Trip Comments: Add trip-specific notes in the summary screen.
- Testing: Includes unit and UI tests using Espresso and JUnit.

## Technologies Used
- Java (Android)
- Firebase Auth
- Firebase Firestore (local use)
- Google Places API
- Jetpack ViewModel & LiveData
- SharedPreferences
- Room Database

## Screenshots

Below are key screens from the application:

### Home / Main Screen
![Main Screen](images/main_screen.png)

### Add Trip Screen
![Add Trip Screen](images/add_trip_screen.png)

###️ Map Screen
![Map Screen](images/map_screen.png)

### Packing List Screen
![Packing Screen](images/packing_screen.png)

### Saved Trips Screen
![Saved Trips Screen](images/saved_trips_screen.png)

### User Profile Screen
![User Screen](images/user_screen.png)

### Entertainment Screen
![Entertainment Screen](images/entertainment_screen.png)

### Trip Summary Screen
![Summary Screen](images/summary_screen.png)

### Settings / Preferences Screen
![Settings Screen](images/settings_screen.png)

### Splash Screen
![Splash Screen](images/splash_screen.png)

## Getting Started

### Prerequisites
Before running this project, ensure:

- Android Studio is installed
This project is built using Android Studio (Chipmunk). You will need it to open, run, and build the app.

- Google Maps API Key is pre-configured
A valid API key is already defined in the project’s strings.xml. No changes are required unless you're upgrading to a new Google Cloud project.

- Firebase is integrated
The app includes an existing Firebase configuration (google-services.json) for authentication and database features. No setup is needed unless you switch to a different Firebase project.

### Installation

1. Download the Project Files

Download the ZIP file containing the full Android Studio project. Then:

- Open Android Studio
- Select *"Open an existing project"*
- Navigate to the unzipped project folder

### 2. Build and Run

- Connect an Android device or use the emulator.
- Press *Run* in Android Studio.

The app should launch and allow access to all features.

## Folder Structure

com.example.finalyearproject/
├── activities/ # All UI screens/Activities
│   ├── AddTripActivity.java
│   ├── DataActivity.java
│   ├── EntertainmentActivity.java
│   ├── MainActivity.java
│   ├── MapActivity.java
│   ├── PackingListActivity.java
│   ├── SavedTripsActivity.java
│   ├── SplashScreenActivity.java
│   ├── TripSummaryActivity.java
│   └── UserProfileActivity.java
│
├── adapters/ # RecyclerView/ListView adapters
│   ├── PackingListAdapter.java
│   └── TripAdapter.java
│
├── dao/ # Room DAO interfaces
│   ├── TripDao.java
│   ├── PackingListDao.java
│   └── LocationDao.java
│
├── database/ # Room database definitions
│   ├── AppDatabase.java
│   ├── PackingListDatabase.java
│   └── TripDatabase.java
│
├── models/ # Data model classes
│   ├── Location.java
│   ├── PackingList.java
│   └── Trip.java
│
├── repository/ # Repository classes (abstraction for data sources)
│   ├── PackingListRepository.java
│   └── TripRepository.java
│
├── utils/ # Common utility/helper classes
│   └── StopConverter.java
│
├── viewmodel/              # ViewModel classes (MVVM pattern)
│   ├── StopConverter.java
│   ├── TripManager.java
│   └── TripViewModel.java


## Developer Info

- Name: Alexander Morrison
- B Number: B00842402
- Email: Morrison-A24@ulster.ac.uk
- University: Ulster University - DLD
- Course: BSc (Hons) Computer Science
- Submitted: 2nd May 2025

## Known Issues

1. Functional Gaps
- Poor entertainment recommendations
While the entertainment section includes a list of podcasts, there is no logic implemented to suggest content based on the passenger types or add own files.

- No real-time routing optimisation
The application exports trips to Google Maps for navigation, but no in-app logic exists for adapting to live traffic, calculating delays, or comparing route options. Routes are static and based on user entry only.

- Fuel cost estimation is limited
The app allows the user to input fuel type, MPG, and price per litre. However, calculations are based on a fixed segment of 10 miles. There is no full-route distance inclusion, and fuel cost estimation is therefore indicative only.

- No breakdown, emergency, or safety tools
Despite being mentioned in user interviews, there is no section within the app offering roadside support info, emergency numbers, or driving advice. This represents a gap in risk-related planning features.

- Trips are not collaborative
Trips are saved against individual Firebase-authenticated users, but there is no feature allowing trips to be shared or co-edited. Group travel planning was deprioritised due to time constraints.

2. Technical and Design Limitations
- Offline use is minimal
Some limited support is available via Google Maps own offline mode, but core app features (saving, loading, navigation) require internet access. No full offline architecture is implemented.

- Fuel estimate relies on manual input
The estimation relies on user-entered MPG and fuel price per litre. This may vary greatly in real-world usage, and there is no API integration to fetch live fuel prices or distances.

- SharedPreferences is used for user data
While convenient for storing lightweight profile information, SharedPreferences is unencrypted and may not be appropriate for sensitive data in a real-world setting.

## License

This project is for educational purposes and not licensed for commercial distribution.