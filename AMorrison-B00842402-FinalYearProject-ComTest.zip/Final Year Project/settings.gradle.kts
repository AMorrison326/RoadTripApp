pluginManagement {
    repositories {
        google()  // Google's Maven repository for Android tools
        mavenCentral()  // Maven Central for libraries
        gradlePluginPortal()  // Gradle Plugin Portal for additional plugins
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "FinalYearProject"
include(":app")
