//package com.example.finalyearproject;
//
//import org.junit.Test;
//
//import static org.junit.Assert.*;
//
//public class ExampleUnitTest {
//
//    @Test
//    public void passengerCount_shouldBeCorrect() {
//        Trip trip = new Trip("FYP Trip", "Paris", "2025-04-01", "2025-04-10",
//                "London", 2, 1, 3, 0);
//        int totalPassengers = trip.getChildren() + trip.getTeenagers() + trip.getAdults() + trip.getElderly();
//        assertEquals(6, totalPassengers);
//    }
//
//    @Test
//    public void tripName_shouldNotBeEmpty() {
//        Trip trip = new Trip("Weekend Escape", "Edinburgh", "2025-05-01", "2025-05-04",
//                "Manchester", 0, 0, 2, 0);
//        assertFalse(trip.getName().isEmpty());
//    }
//}
