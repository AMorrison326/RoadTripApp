//package com.example.finalyearproject.DataActivityTests;
//
//import androidx.test.ext.junit.runners.AndroidJUnit4;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//
//import androidx.test.ext.junit.rules.ActivityScenarioRule;
//
//import org.junit.Rule;
//
//import com.example.finalyearproject.activities.DataActivity;
//import com.example.finalyearproject.activities.MainActivity;
//import com.example.finalyearproject.R;
//import com.example.finalyearproject.ToastMatcher;
//
//import static androidx.test.espresso.Espresso.onView;
//import static androidx.test.espresso.intent.Intents.intended;
//import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
//import static androidx.test.espresso.matcher.ViewMatchers.withId;
//import static androidx.test.espresso.matcher.ViewMatchers.withText;
//import static androidx.test.espresso.assertion.ViewAssertions.matches;
//import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
//import static androidx.test.espresso.action.ViewActions.click;
//
//@RunWith(AndroidJUnit4.class)
//public class DataActivityTest {
//
//    @Rule
//    public ActivityScenarioRule<DataActivity> activityRule =
//            new ActivityScenarioRule<>(DataActivity.class);
//
//    @Test
//    public void signOutButton_logsOutAndShowsToast() {
//        onView(withId(R.id.sign_out_button)).perform(click());
//
//        // Check if the MainActivity is launched
//        intended(hasComponent(MainActivity.class.getName()));
//
//        // Check if the Toast message is displayed
//        onView(withText("Signed out"))
//                .inRoot(new ToastMatcher())
//                .check(matches(isDisplayed()));
//    }
//}
