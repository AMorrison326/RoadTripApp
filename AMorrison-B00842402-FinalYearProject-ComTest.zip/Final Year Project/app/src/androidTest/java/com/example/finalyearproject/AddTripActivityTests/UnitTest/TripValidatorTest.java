//package com.example.finalyearproject.AddTripActivityTests.UnitTest;
//
//import static org.junit.Assert.*;
//
//import org.junit.Test;
//
//public class TripValidatorTest {
//
//    @Test
//    public void testIsTripNameValid_validName_returnsTrue() {
//        assertTrue(TripValidator.isTripNameValid("Summer Trip 2025"));
//    }
//
//    @Test
//    public void testIsTripNameValid_emptyName_returnsFalse() {
//        assertFalse(TripValidator.isTripNameValid(""));
//    }
//
//    @Test
//    public void testIsPassengerCountValid_validCount_returnsTrue() {
//        assertTrue(TripValidator.isPassengerCountValid(2, 1, 3, 0));
//    }
//
//    @Test
//    public void testIsPassengerCountValid_allZero_returnsFalse() {
//        assertFalse(TripValidator.isPassengerCountValid(0, 0, 0, 0));
//    }
//
//    @Test
//    public void testParseIntOrZero_validNumber_returnsParsedInt() {
//        assertEquals(5, TripValidator.parseIntOrZero("5"));
//    }
//
//    @Test
//    public void testParseIntOrZero_emptyString_returnsZero() {
//        assertEquals(0, TripValidator.parseIntOrZero(""));
//    }
//
//    @Test
//    public void testParseIntOrZero_invalidString_returnsZero() {
//        assertEquals(0, TripValidator.parseIntOrZero("abc"));
//    }
//}
