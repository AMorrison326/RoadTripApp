//package com.example.finalyearproject.AddTripActivityTests;
//
//import com.example.finalyearproject.R;
//
//import android.view.View;
//import android.widget.EditText;
//
//import androidx.test.core.app.ActivityScenario;
//import androidx.test.espresso.UiController;
//import androidx.test.espresso.ViewAction;
//import androidx.test.ext.junit.rules.ActivityScenarioRule;
//import androidx.test.ext.junit.runners.AndroidJUnit4;
//
//import org.hamcrest.Matcher;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Rule;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//
//import static androidx.test.espresso.Espresso.onView;
//import static androidx.test.espresso.action.ViewActions.*;
//import static androidx.test.espresso.matcher.ViewMatchers.*;
//import static androidx.test.espresso.assertion.ViewAssertions.matches;
//
//import com.example.finalyearproject.activities.AddTripActivity;
//import com.example.finalyearproject.ToastMatcher;
//
//@RunWith(AndroidJUnit4.class)
//public class AddTripActivityTest {
//
//    @Rule
//    public ActivityScenarioRule<AddTripActivity> activityScenarioRule =
//            new ActivityScenarioRule<>(AddTripActivity.class);
//
//    // Custom wait method (needed for Toasts)
//    public static ViewAction waitFor(final long millis) {
//        return new ViewAction() {
//            @Override
//            public Matcher<View> getConstraints() {
//                return isRoot();
//            }
//
//            @Override
//            public String getDescription() {
//                return "Wait for " + millis + " milliseconds.";
//            }
//
//            @Override
//            public void perform(UiController uiController, View view) {
//                uiController.loopMainThreadForAtLeast(millis);
//            }
//        };
//    }
//
//    @Before
//    public void setUp() {
//        System.setProperty("IS_TESTING", "true"); // To avoid Places Autocomplete UI
//    }
//
//    @After
//    public void tearDown() {
//        System.clearProperty("IS_TESTING");
//    }
//
//    @Test
//    public void saveButtonWithValidDataFinishesActivity() throws InterruptedException {
//        // Wait for the activity to fully render
//        Thread.sleep(1000); // avoid if using IdlingResources
//
//        // Fill in the trip name
//        onView(withId(R.id.trip_name_input)).perform(typeText("Family Trip"), closeSoftKeyboard());
//
//        // Instead of clicking (which launches Places Autocomplete), type directly
//        onView(withId(R.id.destination_input)).perform(replaceText("London, UK"), closeSoftKeyboard());
//
//        // Set trip dates
//        onView(withId(R.id.start_date)).perform(click());
//        onView(withText("OK")).perform(click());
//
//        onView(withId(R.id.end_date)).perform(click());
//        onView(withText("OK")).perform(click());
//
//        // Set passengers
//        onView(withId(R.id.input_children)).perform(typeText("1"), closeSoftKeyboard());
//        onView(withId(R.id.input_adults)).perform(typeText("2"), closeSoftKeyboard());
//
//        // Save trip
//        onView(withId(R.id.save_trip_button)).perform(click());
//
//        // Optional: Assert that the activity has closed or navigated
//    }
//
//    @Test
//    public void saveButtonWithoutTripNameShowsError() {
//        onView(withId(R.id.destination_input)).perform(replaceText("London"), closeSoftKeyboard());
//        onView(withId(R.id.input_children)).perform(typeText("1"), closeSoftKeyboard());
//        onView(withId(R.id.input_adults)).perform(typeText("2"), closeSoftKeyboard());
//
//        onView(withId(R.id.save_trip_button)).perform(click());
//
//        // Replace this with the actual error logic if you have a Toast, Snackbar, or error field
//        // Example if you show error in a TextView:
//        onView(withId(R.id.trip_name_input)).check(matches(isDisplayed()));
//    }
//
//    @Test
//    public void saveButtonWithNoPassengersShowsToastError() {
//        ActivityScenario<AddTripActivity> scenario = ActivityScenario.launch(AddTripActivity.class);
//        scenario.onActivity(activity -> {
//            ((EditText) activity.findViewById(R.id.start_location_input)).setText("Berlin");
//            ((EditText) activity.findViewById(R.id.destination_input)).setText("Paris");
//            activity.setStartLocationName("Berlin");
//            activity.setDestinationName("Paris");
//        });
//
//        onView(withId(R.id.trip_name_input)).perform(typeText("Trip Without Passengers"), closeSoftKeyboard());
//
//
//
//        onView(withId(R.id.input_children)).perform(replaceText(""), closeSoftKeyboard());
//        onView(withId(R.id.input_adults)).perform(replaceText(""), closeSoftKeyboard());
//        onView(withId(R.id.input_teenagers)).perform(replaceText(""), closeSoftKeyboard());
//        onView(withId(R.id.input_elderly)).perform(replaceText(""), closeSoftKeyboard());
//
//        onView(withId(R.id.save_trip_button)).perform(click());
//
//        onView(withText("Please complete all required fields"))
//                .inRoot(new ToastMatcher())
//                .check(matches(isDisplayed()));
//    }
//
//
//    @Test
//    public void saveButtonWithMissingFieldsShowsToastError() {
//        ActivityScenario<AddTripActivity> scenario = ActivityScenario.launch(AddTripActivity.class);
//        scenario.onActivity(activity -> {
//            activity.setDestinationName(null); // Simulate missing destination
//        });
//
//        onView(withId(R.id.trip_name_input)).perform(typeText("Trip With Missing Destination"), closeSoftKeyboard());
//        onView(withId(R.id.input_adults)).perform(typeText("1"), closeSoftKeyboard());
//
//        onView(withId(R.id.save_trip_button)).perform(click());
//
//        onView(withText("Please complete all required fields"))
//                .inRoot(new ToastMatcher())
//                .check(matches(isDisplayed()));
//    }
//
//
//    @Test
//    public void allRequiredFieldsAreVisible() {
//        onView(withId(R.id.trip_name_input)).check(matches(isDisplayed()));
//        onView(withId(R.id.destination_input)).check(matches(isDisplayed()));
//        onView(withId(R.id.input_children)).check(matches(isDisplayed()));
//        onView(withId(R.id.input_adults)).check(matches(isDisplayed()));
//        onView(withId(R.id.start_date)).check(matches(isDisplayed()));
//        onView(withId(R.id.end_date)).check(matches(isDisplayed()));
//        onView(withId(R.id.save_trip_button)).check(matches(isDisplayed()));
//    }
//
//    @Test
//    public void saveTripNavigatesOrShowsSuccessToast() {
//        onView(withId(R.id.trip_name_input)).perform(typeText("My Trip"), closeSoftKeyboard());
//        onView(withId(R.id.destination_input)).perform(replaceText("London, UK"), closeSoftKeyboard());
//        onView(withId(R.id.input_children)).perform(typeText("1"), closeSoftKeyboard());
//        onView(withId(R.id.input_adults)).perform(typeText("2"), closeSoftKeyboard());
//
//        onView(withId(R.id.save_trip_button)).perform(click());
//
//        // If there's a Toast (requires custom matcher), or navigation to another activity:
//        // onView(withText("Trip saved!")).inRoot(withDecorView(not(is(activity.getWindow().getDecorView())))).check(matches(isDisplayed()));
//    }
//
//}
