//package com.example.finalyearproject;
//
//import static org.junit.Assert.assertEquals;
//
//import android.content.Context;
//
//import androidx.test.ext.junit.rules.ActivityScenarioRule;
//import androidx.test.ext.junit.runners.AndroidJUnit4;
//import androidx.test.platform.app.InstrumentationRegistry;
//
//import org.junit.Rule;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//
//import static androidx.test.espresso.Espresso.onView;
//import static androidx.test.espresso.matcher.ViewMatchers.*;
//import static androidx.test.espresso.assertion.ViewAssertions.*;
//
//import com.example.finalyearproject.activities.AddTripActivity;
//
//@RunWith(AndroidJUnit4.class)
//public class ExampleInstrumentedTest {
//
//    @Rule
//    public ActivityScenarioRule<AddTripActivity> activityRule =
//            new ActivityScenarioRule<>(AddTripActivity.class);
//
//    @Test
//    public void useAppContext() {
//        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
//        assertEquals("com.example.finalyearproject", appContext.getPackageName());
//    }
//
//    @Test
//    public void tripNameField_isVisible() {
//        onView(withId(R.id.trip_name_input)).check(matches(isDisplayed()));
//    }
//
//    @Test
//    public void saveButton_isVisible() {
//        onView(withId(R.id.save_trip_button)).check(matches(isDisplayed()));
//    }
//}
