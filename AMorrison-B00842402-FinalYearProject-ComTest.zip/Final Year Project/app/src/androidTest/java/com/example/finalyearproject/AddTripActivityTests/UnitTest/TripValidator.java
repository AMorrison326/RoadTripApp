//package com.example.finalyearproject.AddTripActivityTests.UnitTest;
//
//public class TripValidator {
//
//    public static boolean isTripNameValid(String name) {
//        return name != null && !name.trim().isEmpty();
//    }
//
//    public static boolean isPassengerCountValid(int children, int teens, int adults, int elderly) {
//        return (children + teens + adults + elderly) > 0;
//    }
//
//    public static int parseIntOrZero(String input) {
//        try {
//            input = input.trim();
//            if (input.isEmpty()) return 0;
//            return Integer.parseInt(input);
//        } catch (NumberFormatException e) {
//            return 0;
//        }
//    }
//}
