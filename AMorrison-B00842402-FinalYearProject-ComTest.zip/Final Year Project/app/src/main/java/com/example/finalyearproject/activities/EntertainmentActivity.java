package com.example.finalyearproject.activities;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalyearproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class EntertainmentActivity extends AppCompatActivity {

    private ListView podcastListView;
    private MediaPlayer mediaPlayer;

    //Lists the posdcasts names to be displayed
    private final String[] podcastList = {"Travel Talks", "Journey Jams", "Explorer Diaries", "Wanderlust Weekly"};

    //Audio files for the podcasts
    private final int[] audioFiles = {R.raw.traveltalks, R.raw.journeyjams, R.raw.explorerdiaries, R.raw.wanderlustweekly};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entertainment);

        //Initilises the listview for the podcast titles
        podcastListView = findViewById(R.id.podcast_list);

        //Sets up an array which shows the titles
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, podcastList);
        podcastListView.setAdapter(adapter);

        //Stats a podcast when its selected
        podcastListView.setOnItemClickListener((parent, view, position, id) -> {
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }

            //Creates and starts a media player for the selected audio
            mediaPlayer = MediaPlayer.create(EntertainmentActivity.this, audioFiles[position]);
            mediaPlayer.start();

            //Notifys user of the selection
            Toast.makeText(this, "Playing: " + podcastList[position], Toast.LENGTH_SHORT).show();
        });

        // Bottom Navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_entertainment);
        bottomNav.setOnItemSelectedListener(item ->
        {
            int id = item.getItemId();
            if (id == R.id.nav_home) startActivity(new Intent(this, MainActivity.class));
            else if (id == R.id.nav_saved)
                startActivity(new Intent(this, SavedTripsActivity.class));
            else if (id == R.id.nav_packing)
                startActivity(new Intent(this, PackingListActivity.class));
            else if (id == R.id.nav_add)
                startActivity(new Intent(this, AddTripActivity.class));
            return true;
        });
    }

    //Helps to prevent excessive memory usage
    @Override
    protected void onDestroy() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        super.onDestroy();
    }
}
