package com.example.finalyearproject.utils;

import androidx.room.TypeConverter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class StopConverter {
    //Converts a list of stops into a string format using semicolons
    @TypeConverter
    public String fromList(List<String> stops) {
        return stops != null ? String.join(";", stops) : "";
    }

    //Converts a semicolon string list back to a list of stops
    @TypeConverter
    public List<String> toList(String data) {
        return data == null || data.isEmpty() ? Collections.emptyList() : Arrays.asList(data.split(";"));
    }
}
