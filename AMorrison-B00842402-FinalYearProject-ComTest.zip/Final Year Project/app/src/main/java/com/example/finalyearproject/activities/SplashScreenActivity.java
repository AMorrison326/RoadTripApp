package com.example.finalyearproject.activities;
import com.example.finalyearproject.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashScreenActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //Waits for the layout to finish drawing, then delays for 2s
        findViewById(android.R.id.content).post(() ->
        {
            //shows the transition/splash screen fro 2 seconds
            new Handler().postDelayed(() ->
            {
                //Retrieves current user,proceeds to the main page and then closes the activity so the user cant return
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }, 2000); // Show splash for 2s
        });
    }
}
