package com.example.finalyearproject.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;

import com.example.finalyearproject.models.PackingList;
import com.example.finalyearproject.dao.PackingListDao;
import com.example.finalyearproject.database.PackingListDatabase;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PackingListRepository
{

    private final PackingListDao packingListDao;
    private final ExecutorService executorService;

    //Constructor: Gets instance of the database and DAO
    public PackingListRepository(Application application)
    {
        PackingListDatabase database = PackingListDatabase.getInstance(application);
        packingListDao = database.packingListDao();
        executorService = Executors.newFixedThreadPool(2);
    }

    //Retrieves a list of all distinct age groups from the database
    public LiveData<List<String>> getAgeGroups()
    {
        return packingListDao.getAgeGroups();
    }

    //Gets packing list items which are filtered by age group
    public LiveData<List<PackingList>> getPackingListByAgeGroup(String ageGroup)
    {
        return packingListDao.getPackingListByAgeGroup(ageGroup);
    }

    //Inserts a new packing item into the database in the background
    public void insertItem(PackingList item)
    {
        executorService.execute(() -> packingListDao.insert(item));
    }
}
