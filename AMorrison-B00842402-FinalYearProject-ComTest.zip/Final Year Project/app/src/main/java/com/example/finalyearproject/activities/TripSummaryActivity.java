package com.example.finalyearproject.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.finalyearproject.R;
import com.example.finalyearproject.viewmodel.TripViewModel;

import java.util.List;

public class TripSummaryActivity extends AppCompatActivity {

    //Trip details and references
    private String startLocation, destination, tripName, startDate, endDate;
    private int tripId, children, teenagers, adults, elderly;
    private List<String> additionalStops;

    //UI elements
    private EditText commentsEditText;
    private TripViewModel tripViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_summary);

        //Initilises the viewmodel to retrieve trip data
        tripViewModel = new ViewModelProvider(this).get(TripViewModel.class);

        //Binds the views from the layout
        TextView tripNameView = findViewById(R.id.trip_name_summary);
        TextView startLocationView = findViewById(R.id.start_location_summary);
        TextView destinationView = findViewById(R.id.destination_summary);
        TextView startDateView = findViewById(R.id.start_date_summary);
        TextView endDateView = findViewById(R.id.end_date_summary);
        TextView childrenView = findViewById(R.id.children_summary);
        TextView teenagersView = findViewById(R.id.teenagers_summary);
        TextView adultsView = findViewById(R.id.adults_summary);
        TextView elderlyView = findViewById(R.id.elderly_summary);
        TextView fuelEstimateView = findViewById(R.id.fuel_estimate_summary);
        commentsEditText = findViewById(R.id.comments_edit_text);

        //Retrieves the trip ID from the previous screen
        int tripId = getIntent().getIntExtra("trip_id", -1);

        if (tripId != -1) {
            //Loads the trip data and updates the UI
            tripViewModel.getTripById(tripId).observe(this, trip -> {
                if (trip != null) {
                    // Assign details
                    tripName = trip.getName();
                    startLocation = trip.getStartLocation();
                    destination = trip.getDestination();
                    additionalStops = trip.getAdditionalStops();

                    //Display  trips data
                    tripNameView.setText("Trip Name: " + tripName);
                    startLocationView.setText("Start Location: " + startLocation);
                    destinationView.setText("Destination: " + destination);
                    startDateView.setText("Start Date: " + trip.getStartDate());
                    endDateView.setText("End Date: " + trip.getEndDate());
                    childrenView.setText("Children: " + trip.getChildren());
                    teenagersView.setText("Teenagers: " + trip.getTeenagers());
                    adultsView.setText("Adults: " + trip.getAdults());
                    elderlyView.setText("Elderly: " + trip.getElderly());
                    commentsEditText.setText(trip.getComments());

                    //Estimates the fuel cost based on profile page inputs
                    calculateFuelEstimate(fuelEstimateView);
                }
            });
        } else {
            Toast.makeText(this, "Trip ID missing", Toast.LENGTH_SHORT).show();
            finish();
        }

        //Sets up buttons and their listeners
        Button startNavigationButton = findViewById(R.id.start_navigation_button);
        Button saveCommentsButton = findViewById(R.id.save_comments_button);
        Button closeSummaryButton = findViewById(R.id.close_summary_button);

        startNavigationButton.setOnClickListener(v -> openGoogleMapsNavigation());
        saveCommentsButton.setOnClickListener(v -> saveComments(tripId));
        closeSummaryButton.setOnClickListener(v -> finish());
    }

    //Calculates an estimate of fuel costs for 10miles based of the user profile data
    private void calculateFuelEstimate(TextView fuelEstimateView) {
        SharedPreferences prefs = getSharedPreferences("user_profile", MODE_PRIVATE);

        double mpg = Double.parseDouble(prefs.getString("mpg", "0"));
        double fuelCostPerLitre = Double.parseDouble(prefs.getString("cost", "0"));  // was "fuel_price"

        double segmentMiles = 10.0;

        if (mpg > 0 && fuelCostPerLitre > 0) {
            double litresPerMile = 4.546 / mpg;
            double litresUsed = litresPerMile * segmentMiles;
            double cost = litresUsed * fuelCostPerLitre;

            String estimate = String.format("Est. per %.0f miles:\n%.2f litres ≈ £%.2f",
                    segmentMiles, litresUsed, cost);
            fuelEstimateView.setText(estimate);
        } else {
            fuelEstimateView.setText("Fuel estimate unavailable");
        }
    }

//Opens google maps and inputs stops into its navigation
    private void openGoogleMapsNavigation() {
        if (startLocation != null && destination != null &&
                !startLocation.trim().isEmpty() && !destination.trim().isEmpty()) {

            StringBuilder uriBuilder = new StringBuilder("https://www.google.com/maps/dir/?api=1");
            uriBuilder.append("&origin=").append(startLocation.replace(" ", "+"));
            uriBuilder.append("&destination=").append(destination.replace(" ", "+"));
            uriBuilder.append("&travelmode=driving");

            //Additional stops are added as waypoint
            if (additionalStops != null && !additionalStops.isEmpty()) {
                uriBuilder.append("&waypoints=");
                for (int i = 0; i < additionalStops.size(); i++) {
                    uriBuilder.append(additionalStops.get(i).replace(" ", "+"));
                    if (i < additionalStops.size() - 1) {
                        uriBuilder.append("|");
                    }
                }
            }

            Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uriBuilder.toString()));
            mapIntent.setPackage("com.google.android.apps.maps");

            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uriBuilder.toString())));
            }

        } else {
            //Fallback for google maps not being found/installed
            Toast.makeText(this, "Trip details missing", Toast.LENGTH_SHORT).show();
        }
    }

    //Saves the user comments to the trips record
    private void saveComments(int tripId) {
        String newComment = commentsEditText.getText().toString().trim();
        if (newComment.isEmpty()) {
            Toast.makeText(this, "Please enter a comment before saving.", Toast.LENGTH_SHORT).show();
            return;
        }

        tripViewModel.getTripById(tripId).observe(this, trip -> {
            if (trip != null) {
                trip.setComments(newComment);
                tripViewModel.updateTrip(trip);
                Toast.makeText(this, "Comment saved successfully!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
