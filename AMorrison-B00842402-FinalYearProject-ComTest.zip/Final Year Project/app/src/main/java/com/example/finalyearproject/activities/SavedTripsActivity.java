package com.example.finalyearproject.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalyearproject.R;
import com.example.finalyearproject.adapters.TripAdapter;
import com.example.finalyearproject.viewmodel.TripViewModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SavedTripsActivity extends AppCompatActivity
{

    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TripAdapter tripAdapter;
    private TripViewModel tripViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_trips);

        //Will locate the visual elements in the layout
        progressBar = findViewById(R.id.progress_bar);
        recyclerView = findViewById(R.id.recycler_view);

        //Sets up the recyclerView to show trips vertically
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        tripAdapter = new TripAdapter(this);
        recyclerView.setAdapter(tripAdapter);

        //Sets up the ViewModel and begins to observe data
        setupViewModel();

        //Bottom Navigation initilisation
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_saved);

        bottomNav.setOnItemSelectedListener(item ->
        {
            int id = item.getItemId();
            if (id == R.id.nav_home)
            {
                startActivity(new Intent(this, MainActivity.class));
            }
            else if (id == R.id.nav_add)
            {
                startActivity(new Intent(this, AddTripActivity.class));
            }
            else if (id == R.id.nav_saved)
            {
                return true;
            }
            else if (id == R.id.nav_packing)
            {
                startActivity(new Intent(this, PackingListActivity.class));
            }
            else if (id == R.id.nav_entertainment)
            {
                startActivity(new Intent(this, EntertainmentActivity.class));
            }
            return true;
        });
    }

    //Connects to the viewmodel and starts to observe the saved trips and displays them in the recyclerview
    private void setupViewModel()
    {
        //Shows the loading spinner
        progressBar.setVisibility(View.VISIBLE);

        //Initialises the viewModel
        tripViewModel = new ViewModelProvider(this).get(TripViewModel.class);

        //Find the current user whos logged in
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null)
        {
            //FInds and displays the trips that belong to the user
            tripViewModel.getTripsForUser(user.getUid()).observe(this, trips ->
            {
                //Hides the progressbar
                progressBar.setVisibility(View.GONE);
                if (trips != null)
                {
                    tripAdapter.setTrips(trips);
                }
            });
        }
        else
        {
            //Shows a message that no user is signed in
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "User not signed in", Toast.LENGTH_SHORT).show();
        }
    }

}
