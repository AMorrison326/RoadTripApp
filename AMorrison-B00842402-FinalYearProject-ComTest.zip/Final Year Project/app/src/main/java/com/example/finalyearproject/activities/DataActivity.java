package com.example.finalyearproject.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalyearproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class DataActivity extends AppCompatActivity {

    //UI logout, reminder and stats elements
    private Button signOutButton;
    private Spinner reminderSpinner;
    private TextView totalTripsTextView, mostVisitedTextView, referencesListTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        //Iniiliese components, loads saved data and sets up the reminder logic
        initializeViews();
        loadUserStats();
        setupReminderSpinner();

//Sets up the nav bar and its logic
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.post(() -> {
            bottomNav.getMenu().setGroupCheckable(0, true, false);
            for (int i = 0; i < bottomNav.getMenu().size(); i++) {
                bottomNav.getMenu().getItem(i).setChecked(false);
            }
            bottomNav.getMenu().setGroupCheckable(0, true, true);
        });

        bottomNav.setOnItemSelectedListener(item ->
        {
            item.setChecked(false);
            int id = item.getItemId();
            if (id == R.id.nav_home)
            {
                startActivity(new Intent(this, MainActivity.class));
            }
            else if (id == R.id.nav_add)
            {
                startActivity(new Intent(this, AddTripActivity.class));
            }
            else if (id == R.id.nav_saved)
            {
                startActivity(new Intent(this, SavedTripsActivity.class));
            }
            else if (id == R.id.nav_packing)
            {
                startActivity(new Intent(this, PackingListActivity.class));
            }
            else if (id == R.id.nav_entertainment)
            {
                startActivity(new Intent(this, EntertainmentActivity.class));
            }
            return true;
        });
    }

    //Connects the views with thier IDS and logout behviour
    private void initializeViews() {
        signOutButton = findViewById(R.id.sign_out_button);
        reminderSpinner = findViewById(R.id.reminder_spinner);
        referencesListTextView = findViewById(R.id.references_list);

        signOutButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    //Loads the reminder preferences and listens for any changes
    private void setupReminderSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.reminder_options,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reminderSpinner.setAdapter(adapter);

        SharedPreferences prefs = getSharedPreferences("user_profile", MODE_PRIVATE);
        String savedReminder = prefs.getString("reminder_advance", "1 day before");
        int pos = adapter.getPosition(savedReminder);
        reminderSpinner.setSelection(pos);

        reminderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = parent.getItemAtPosition(position).toString();
                prefs.edit().putString("reminder_advance", selected).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    //Identifies the references for this project
    private void loadUserStats() {
        referencesListTextView.setText(
            "1. Google Maps Platform Documentation: https://developers.google.com/maps/documentation\n" +
            "2. Firebase Android Documentation: https://firebase.google.com/docs/android/setup\n" +
            "3. Android Developers – Room Persistence Library: https://developer.android.com/training/data-storage/room\n" +
            "4. Jetpack Navigation Component: https://developer.android.com/guide/navigation\n" +
            "5. Material Design Guidelines: https://m3.material.io/\n"
        );
    }
}
