package com.example.finalyearproject.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;

import com.example.finalyearproject.models.Trip;
import com.example.finalyearproject.dao.TripDao;
import com.example.finalyearproject.database.TripDatabase;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TripRepository {

    private final TripDao tripDao;
    private final LiveData<List<Trip>> allTrips;
    private final ExecutorService executorService;

    //Constructor which initilises the room database and DAO reference
    public TripRepository(Application application) {
        TripDatabase database = TripDatabase.getInstance(application);
        tripDao = database.tripDao();
        allTrips = tripDao.getAllTrips();
        executorService = Executors.newSingleThreadExecutor();
    }

    //Inserts a trip
    public void insertTrip(Trip trip) {
        executorService.execute(() -> tripDao.insert(trip));
    }

    //Inserts a trip and returns the ID
    public long insertTripAndReturnId(Trip trip) {
        return tripDao.insert(trip);
    }

    //Updates an existing trip
    public void updateTrip(Trip trip) {
        executorService.execute(() -> tripDao.update(trip));
    }

    //Gathers all trips
    public LiveData<List<Trip>> getAllTrips() {
        return allTrips;
    }

    //Gathers all trips for a specific user
    public LiveData<List<Trip>> getTripsForUser(String userId) {
        return tripDao.getTripsForUser(userId);
    }

    //Retrieves a specific trip using its trip ID
    public LiveData<Trip> getTripById(int tripId) {
        return tripDao.getTripById(tripId);
    }

}
