package com.example.finalyearproject.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalyearproject.R;
import com.example.finalyearproject.activities.TripSummaryActivity;
import com.example.finalyearproject.models.Trip;

import java.util.List;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.TripViewHolder> {
    private final Context context;
    private List<Trip> trips;

    public TripAdapter(Context context) {
        this.context = context;
    }

    //Method to set the list of trips
    public void setTrips(List<Trip> trips) {
        this.trips = trips;
        notifyDataSetChanged();
    }

    //Sets each trip care from teh item_trips layout
    @NonNull
    @Override
    public TripViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_trip, parent, false);
        return new TripViewHolder(view);
    }

    //Binds the trip information to hte textviews
    @Override
    public void onBindViewHolder(@NonNull TripViewHolder holder, int position) {
        Trip trip = trips.get(position);

        holder.tripNameTextView.setText(trip.getName());
        holder.tripDestinationTextView.setText("Destination: " + trip.getDestination());
        holder.tripStartDateTextView.setText("Start Date: " + trip.getStartDate());
        holder.tripEndDateTextView.setText("End Date: " + trip.getEndDate());
        holder.tripStartLocationTextView.setText("Start Location: " + trip.getStartLocation());

        String passengerText = "Passengers: " +
                trip.getAdults() + " Adults, " +
                trip.getTeenagers() + " Teenagers, " +
                trip.getChildren() + " Children, " +
                trip.getElderly() + " Elderly";
        holder.tripPassengersTextView.setText(passengerText);

        //Handles a trip being clicked on to direct to the summary
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), TripSummaryActivity.class);
            intent.putExtra("trip_id", trip.getId());
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return trips == null ? 0 : trips.size();
    }

    public static class TripViewHolder extends RecyclerView.ViewHolder {
        TextView tripNameTextView;
        TextView tripDestinationTextView;
        TextView tripStartDateTextView;
        TextView tripEndDateTextView;
        TextView tripStartLocationTextView;
        TextView tripPassengersTextView;

        public TripViewHolder(@NonNull View itemView) {
            super(itemView);
            tripNameTextView = itemView.findViewById(R.id.trip_name);
            tripDestinationTextView = itemView.findViewById(R.id.trip_destination);
            tripStartDateTextView = itemView.findViewById(R.id.trip_start_date);
            tripEndDateTextView = itemView.findViewById(R.id.trip_end_date);
            tripStartLocationTextView = itemView.findViewById(R.id.trip_start_location);
            tripPassengersTextView = itemView.findViewById(R.id.trip_passengers);
        }
    }
}
