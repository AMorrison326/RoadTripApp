package com.example.finalyearproject.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "packing_list")
public class PackingList
{
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String ageGroup;
    private String item;
    private String type;

    //Constructor
    public PackingList(String ageGroup, String item, String type)
    {
        this.ageGroup = ageGroup;
        this.item = item;
        this.type = type;
    }

    //Optional constructor
    public PackingList(String ageGroup, String item)
    {
        this.ageGroup = ageGroup;
        this.item = item;
        this.type = "Custom";
    }

    //Default constructor
    public PackingList() {}

    //Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
