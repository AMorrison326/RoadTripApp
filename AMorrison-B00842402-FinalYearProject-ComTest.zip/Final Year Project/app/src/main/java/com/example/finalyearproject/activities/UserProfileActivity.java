package com.example.finalyearproject.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalyearproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.squareup.picasso.Picasso;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class UserProfileActivity extends AppCompatActivity
{

    private TextView userNameText, userEmailText;
    private ImageView userProfileImage;
    private Button saveButton, signOutButton;
    private EditText vehicleMake, mpgInput, fuelCostInput;
    private Spinner fuelTypeSpinner, preferredRouteSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        //Finds the current signed in firebase user
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        //UI references to display teh users information and inputted data
        userNameText = findViewById(R.id.user_name_display);
        userEmailText = findViewById(R.id.user_email_display);
        userProfileImage = findViewById(R.id.user_image);

        preferredRouteSpinner = findViewById(R.id.preferred_route_spinner);
        vehicleMake = findViewById(R.id.vehicle_make);
        mpgInput = findViewById(R.id.mpg);
        fuelTypeSpinner = findViewById(R.id.fuel_type_spinner);
        fuelCostInput = findViewById(R.id.fuel_cost);

        saveButton = findViewById(R.id.save_profile_button);
        signOutButton = findViewById(R.id.sign_out_button);

        //Populates the route and fuel spinner sections
        ArrayAdapter<CharSequence> routeAdapter = ArrayAdapter.createFromResource(
                this, R.array.preferred_routes, android.R.layout.simple_spinner_item);
        routeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        preferredRouteSpinner.setAdapter(routeAdapter);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.fuel_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fuelTypeSpinner.setAdapter(adapter);

    //If the users is authenticated it will populate their profile information
        if (currentUser != null)
        {
            userNameText.setText(currentUser.getDisplayName() != null ? currentUser.getDisplayName() : "Guest");
            userEmailText.setText(currentUser.getEmail() != null ? currentUser.getEmail() : "Email not available");

            if (currentUser.getPhotoUrl() != null)
            {
                Picasso.get()
                        .load(currentUser.getPhotoUrl())
                        .placeholder(R.drawable.profile)
                        .into(userProfileImage);
            }
            else
            {
                userProfileImage.setImageResource(R.drawable.profile);
            }

            //Nav bar set up and controls
            BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
            bottomNav.post(() ->
            {
                bottomNav.getMenu().setGroupCheckable(0, true, false);
                for (int i = 0; i < bottomNav.getMenu().size(); i++)
                {
                    bottomNav.getMenu().getItem(i).setChecked(false);
                }
                bottomNav.getMenu().setGroupCheckable(0, true, true);
            });


            bottomNav.setOnItemSelectedListener(item ->
            {
                item.setChecked(false);
                int id = item.getItemId();
                if (id == R.id.nav_home)
                {
                    startActivity(new Intent(this, MainActivity.class));
                }
                else if (id == R.id.nav_add)
                {
                    startActivity(new Intent(this, AddTripActivity.class));
                }
                else if (id == R.id.nav_saved)
                {
                    startActivity(new Intent(this, SavedTripsActivity.class));
                }
                else if (id == R.id.nav_packing)
                {
                    startActivity(new Intent(this, PackingListActivity.class));
                }
                else if (id == R.id.nav_entertainment)
                {
                    startActivity(new Intent(this, EntertainmentActivity.class));
                }
                return true;
            });
        }

        //Loads an existing profile if its available
        loadProfile();

        //Handles the save and signing out interactions
        saveButton.setOnClickListener(v -> saveProfile());

        signOutButton.setOnClickListener(v ->
        {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(UserProfileActivity.this, "Signed out", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    //Stores the validated inputs to the users profile by use of sharedpreferences
    private void saveProfile()
    {
        String route = preferredRouteSpinner.getSelectedItem().toString();
        String vehicle = vehicleMake.getText().toString().trim();
        String mpg = mpgInput.getText().toString().trim();
        String fuelType = fuelTypeSpinner.getSelectedItem().toString();
        String cost = fuelCostInput.getText().toString().trim();


        if (route.equals("Select Route") || route.isEmpty()) {
            Toast.makeText(this, "Please select a preferred route", Toast.LENGTH_SHORT).show();
            return;
        }

        if (cost.isEmpty()) {
            fuelCostInput.setError("Fuel cost is required");
            return;
        }
        try {
            double parsedCost = Double.parseDouble(cost);
            if (parsedCost <= 0) {
                fuelCostInput.setError("Enter a valid fuel cost");
                return;
            }
        } catch (NumberFormatException e) {
            fuelCostInput.setError("Enter a numeric value");
            return;
        }


        SharedPreferences sharedPreferences = getSharedPreferences("user_profile", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("preferred_route", route);
        editor.putString("vehicle_make", vehicle);
        editor.putString("fuel_type", fuelType);
        editor.putString("mpg", mpg);
        editor.putString("cost", cost);
        editor.apply();

        Toast.makeText(this, "Profile Saved", Toast.LENGTH_SHORT).show();
    }

    //Loads and displays the users preferences using sharedpreferences
    private void loadProfile()
    {
        SharedPreferences sharedPreferences = getSharedPreferences("user_profile", MODE_PRIVATE);
        String savedRoute = sharedPreferences.getString("preferred_route", "");
        if (!savedRoute.isEmpty()) {
            ArrayAdapter adapter = (ArrayAdapter) preferredRouteSpinner.getAdapter();
            int position = adapter.getPosition(savedRoute);
            if (position >= 0) {
                preferredRouteSpinner.setSelection(position);
            }
        }
        vehicleMake.setText(sharedPreferences.getString("vehicle_make", ""));
        mpgInput.setText(sharedPreferences.getString("mpg", ""));
        fuelCostInput.setText(sharedPreferences.getString("cost", ""));

        String fuel = sharedPreferences.getString("fuel_type", "");
        if (!fuel.isEmpty()) {
            ArrayAdapter adapter = (ArrayAdapter) fuelTypeSpinner.getAdapter();
            int position = adapter.getPosition(fuel);
            if (position >= 0) {
                fuelTypeSpinner.setSelection(position);
            }
        }
    }
}