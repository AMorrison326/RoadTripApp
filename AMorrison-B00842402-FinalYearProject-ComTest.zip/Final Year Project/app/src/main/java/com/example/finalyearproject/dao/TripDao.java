package com.example.finalyearproject.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.finalyearproject.models.Trip;

import java.util.List;

@Dao
public interface TripDao {

    //Inserts a new trip into the database
    @Insert
    long insert(Trip trip);

    //Inserts a trip
    @Update
    void update(Trip trip);

    //Updates existing trips
    @Query("SELECT * FROM trips ORDER BY id DESC")
    LiveData<List<Trip>> getAllTrips();

    //Retrieve all of the saved trips
    @Query("SELECT * FROM trips WHERE userId = :userId ORDER BY id DESC")
    LiveData<List<Trip>> getTripsForUser(String userId);

    //Gathers a trips data by its ID
    @Query("SELECT * FROM trips WHERE id = :tripId LIMIT 1")
    LiveData<Trip> getTripById(int tripId);
}
