package com.example.finalyearproject.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.finalyearproject.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import android.content.Intent;
import com.google.android.material.bottomnavigation.BottomNavigationView;


import java.util.Arrays;

/**
 * Activity that displays a Google Map with a Places Autocomplete search bar.
 */
public class MapActivity extends AppCompatActivity implements OnMapReadyCallback
{
    //Loads the map element
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        // Initialize Places SDK
        if (!Places.isInitialized())
        {
            Places.initialize(getApplicationContext(), getString(R.string.google_maps_key));
        }

// Sets up nav bar and the relevant logic
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.post(() -> {
            bottomNav.getMenu().setGroupCheckable(0, true, false);
            for (int i = 0; i < bottomNav.getMenu().size(); i++) {
                bottomNav.getMenu().getItem(i).setChecked(false);
            }
            bottomNav.getMenu().setGroupCheckable(0, true, true);
        });

        bottomNav.setOnItemSelectedListener(item ->
        {
            item.setChecked(false);
            int id = item.getItemId();
            if (id == R.id.nav_home)
            {
                startActivity(new Intent(this, MainActivity.class));
            }
            else if (id == R.id.nav_add)
            {
                startActivity(new Intent(this, AddTripActivity.class));
            }
            else if (id == R.id.nav_saved)
            {
                startActivity(new Intent(this, SavedTripsActivity.class));
            }
            else if (id == R.id.nav_entertainment)
            {
                startActivity(new Intent(this, EntertainmentActivity.class));
            }
            return true;
        });


        // Initialize location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Attaches AutocompleteSupportFragment dynamically
        AutocompleteSupportFragment autocompleteFragment = new AutocompleteSupportFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.autocomplete_fragment_container, autocompleteFragment)
                .commit();


        // Configures autocomplete
        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener()
        {
            @Override
            public void onPlaceSelected(@NonNull Place place)
            {
                LatLng selectedLatLng = place.getLatLng();
                if (selectedLatLng != null && mMap != null)
                {
                    mMap.addMarker(new MarkerOptions().position(selectedLatLng).title(place.getName()));
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(selectedLatLng, 15));
                }
            }

            @Override
            public void onError(@NonNull com.google.android.gms.common.api.Status status)
            {
                Toast.makeText(MapActivity.this, "Place selection failed: " + status.getStatusMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // Load Google Map
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null)
        {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        mMap = googleMap;

        //Checks the map request permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            //Will ask the user for their location
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }

        //Enable location
        mMap.setMyLocationEnabled(true);

        //Shows the last known location and enables location button in the map element
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location ->
        {
            if (location != null)
            {
                LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.addMarker(new MarkerOptions().position(userLocation).title("Your Location"));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15));
            }
            else
            {
                Toast.makeText(this, "Unable to fetch location.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        //Will re-attempt to load the map area if the location permission is granted
        if (requestCode == 1 &&
                grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED)
        {
            onMapReady(mMap);
        }
        else
        {
            Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}
