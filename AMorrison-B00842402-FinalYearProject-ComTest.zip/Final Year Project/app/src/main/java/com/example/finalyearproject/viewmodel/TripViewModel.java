package com.example.finalyearproject.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.finalyearproject.models.Trip;
import com.example.finalyearproject.repository.TripRepository;

import java.util.List;

public class TripViewModel extends AndroidViewModel
{

    private final TripRepository tripRepository;

    //Constructor initilises the repository
    public TripViewModel(@NonNull Application application)
    {
        super(application);
        tripRepository = new TripRepository(application);
    }

    //All trips are returned as livedata
    public LiveData<List<Trip>> getAllTrips()
    {
        return tripRepository.getAllTrips();
    }

    //A specific users trips are returned
    public LiveData<List<Trip>> getTripsForUser(String userId)
    {
        return tripRepository.getTripsForUser(userId);
    }

    //Inserts a new trip
    public void insertTrip(Trip trip)
    {
        tripRepository.insertTrip(trip);
    }

    //Updates an existing trip
    public void updateTrip(Trip trip)
    {
        tripRepository.updateTrip(trip);
    }

    //Fetches a trip using the ID as livedata
    public LiveData<Trip> getTripById(int tripId)
    {
        return tripRepository.getTripById(tripId);
    }

    //Inserts a trip and returns the row ID immediately
    public long insertTripAndReturnId(Trip trip) {
        return tripRepository.insertTripAndReturnId(trip);
    }
}
