package com.example.finalyearproject.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.finalyearproject.utils.StopConverter;
import com.example.finalyearproject.dao.TripDao;
import com.example.finalyearproject.models.Trip;

@Database(entities = {Trip.class}, version = 5, exportSchema = false)
@TypeConverters({StopConverter.class})
public abstract class TripDatabase extends RoomDatabase
{
    private static TripDatabase instance;

    public abstract TripDao tripDao();

    public static synchronized TripDatabase getInstance(Context context)
    {
        if (instance == null)
        {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            TripDatabase.class, "trip_database")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
