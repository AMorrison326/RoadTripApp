package com.example.finalyearproject.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Delete;

import com.example.finalyearproject.models.Location;

import java.util.List;

@Dao
public interface LocationDao
{
    //Fetches the saved locations from the database
    @Query("SELECT * FROM locations")
    LiveData<List<Location>> getAllLocations();

    //Inserts new locations to teh databse
    @Insert
    void insert(Location location);

    //Deletes locations from the database
    @Delete
    void delete(Location location);
}
