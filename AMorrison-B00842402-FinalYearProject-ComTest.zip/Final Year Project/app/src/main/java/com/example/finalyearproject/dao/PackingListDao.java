package com.example.finalyearproject.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.finalyearproject.models.PackingList;

import java.util.List;


//DAO for managing access to packing list data.
@Dao
public interface PackingListDao
{
    //Inserts a new item to the packing list
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(PackingList item);

    //Inserts multiple items into the packing list
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<PackingList> items);

    //Returns the live list of age groups in teh packing list
    @Query("SELECT DISTINCT ageGroup FROM packing_list") // Ensure column exists
    LiveData<List<String>> getAgeGroups();

    //Returns the live list of packing list items
    @Query("SELECT * FROM packing_list WHERE ageGroup = :ageGroup")
    LiveData<List<PackingList>> getPackingListByAgeGroup(String ageGroup);
}
