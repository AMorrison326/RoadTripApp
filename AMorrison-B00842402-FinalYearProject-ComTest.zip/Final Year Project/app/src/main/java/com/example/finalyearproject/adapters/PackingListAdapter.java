package com.example.finalyearproject.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalyearproject.R;
import com.example.finalyearproject.models.PackingList;

import java.util.List;

public class PackingListAdapter extends RecyclerView.Adapter<PackingListAdapter.ViewHolder>
{
    private List<PackingList> packingList;

    public PackingListAdapter(List<PackingList> packingList)
    {
        this.packingList = packingList;
    }

    //Sets the item layout for each packing list entry

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_packing_list, parent, false);
        return new ViewHolder(view);
    }

    //Binds the packing list to the view
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        PackingList item = packingList.get(position);
        holder.textItem.setText(item.getItem());
    }

    @Override
    public int getItemCount()
    {
        return packingList.size();
    }

    //Updates the adapter with the new packing list
    public void updatePackingList(List<PackingList> newList)
    {
        packingList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView textItem;

        ViewHolder(View itemView)
        {
            super(itemView);
            textItem = itemView.findViewById(R.id.text_item);
        }
    }
}
