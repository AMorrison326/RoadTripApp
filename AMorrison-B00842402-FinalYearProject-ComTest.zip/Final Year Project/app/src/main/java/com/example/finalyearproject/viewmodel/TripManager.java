package com.example.finalyearproject.viewmodel;

import com.example.finalyearproject.models.Trip;

import java.util.ArrayList;

public class TripManager
{

    private static TripManager instance;  // Singleton instance
    private final ArrayList<Trip> trips;

    private TripManager()
    {
        trips = new ArrayList<>();
    }

    //Retrieves a single instance of trip manager
    public static synchronized TripManager getInstance()
    {
        if (instance == null)
        {
            instance = new TripManager();
        }
        return instance;
    }

    //Adds a new trip teh the memory list
    public void addTrip(Trip trip)
    {
        trips.add(trip);
    }

    //Returns all stored lists
    public ArrayList<Trip> getTrips()
    {
        return trips;
    }

    //Replaces a trip at a specific index with an updated one
    public void editTrip(int index, Trip updatedTrip)
    {
        if (index >= 0 && index < trips.size())
        {
            trips.set(index, updatedTrip);
        }
    }

    //Returns teh trip at a specific index or returns null
    public Trip getTrip(int index)
    {
        if (index >= 0 && index < trips.size())
        {
            return trips.get(index);
        }
        return null;
    }
}
