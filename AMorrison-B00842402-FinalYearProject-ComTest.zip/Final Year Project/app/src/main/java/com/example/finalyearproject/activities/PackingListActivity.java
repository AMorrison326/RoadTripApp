package com.example.finalyearproject.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalyearproject.adapters.PackingListAdapter;
import com.example.finalyearproject.R;
import com.example.finalyearproject.models.PackingList;
import com.example.finalyearproject.repository.PackingListRepository;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PackingListActivity extends AppCompatActivity
{

    private RecyclerView recyclerView;
    private PackingListAdapter adapter;
    private Spinner spinnerAge;
    private PackingListRepository repository;
    private EditText editTextNewItem;
    private Button buttonAddItem;
    private String selectedAgeGroup;

    //Cintains the default item suggestions based on individual age groups
    private final Map<String, List<String>> predefinedPackingLists = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_packing_list);

        // UI initializations
        recyclerView = findViewById(R.id.recycler_view);
        editTextNewItem = findViewById(R.id.edit_text_new_item);
        buttonAddItem = findViewById(R.id.button_add_item);
        spinnerAge = findViewById(R.id.spinner_age);
        repository = new PackingListRepository(getApplication());

        //REcycler for dynamic list updates
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PackingListAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        //Populates the spinners and listeners
        initializePredefinedPackingLists();
        loadAgeGroups();
        setupSpinnerListener();

        //Sets up button for users to add custom items
        buttonAddItem.setOnClickListener(view ->
        {
            String newItem = editTextNewItem.getText().toString().trim();
            if (newItem.isEmpty())
            {
                editTextNewItem.setError("Item name is required");
                return;
            }
            if (selectedAgeGroup == null)
            {
                Toast.makeText(this, "Please select an age group", Toast.LENGTH_SHORT).show();
                return;
            }
            addCustomItem(newItem);
        });

        //Setup navigation bar at bottom of the page
        setupBottomNavigation();
    }

    //Controls the bottom nav bar
    private void setupBottomNavigation()
    {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_packing);
        bottomNav.setOnItemSelectedListener(item ->
        {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                overridePendingTransition(0, 0);
                return true;
            }
            else if (id == R.id.nav_add)
            {
                startActivity(new Intent(this, AddTripActivity.class));
                overridePendingTransition(0, 0);
                return true;
            }
            else if (id == R.id.nav_saved)
            {
                startActivity(new Intent(this, SavedTripsActivity.class));
                overridePendingTransition(0, 0);
                return true;
            }
            else if (id == R.id.nav_entertainment)
            {
                startActivity(new Intent(this, EntertainmentActivity.class));
                overridePendingTransition(0, 0);
                return true;
            }
            else if (id == R.id.nav_packing)
            {
                return true;
            }
            return false;
        });
    }

// Defines the hard coded item and age lists
    private void initializePredefinedPackingLists()
    {
        predefinedPackingLists.put("Children", Arrays.asList("Toys", "Snacks", "Extra Clothes", "Water Bottle"));
        predefinedPackingLists.put("Teens", Arrays.asList("Phone Charger", "Headphones", "Notebook", "Snacks"));
        predefinedPackingLists.put("Adults", Arrays.asList("Passport", "Wallet", "Sunglasses", "Travel Pillow"));
        predefinedPackingLists.put("Elderly", Arrays.asList("Medication", "Reading Glasses", "Comfortable Shoes", "Water Bottle"));
    }

    //Loads and upadtes the age groups to the UI
    private void loadAgeGroups()
    {
        repository.getAgeGroups().observe(this, ageGroups ->
        {
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, ageGroups);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerAge.setAdapter(spinnerAdapter);
        });
    }

    //Sets up the listener of the spinner for when user changes age group
    private void setupSpinnerListener()
    {
        spinnerAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                selectedAgeGroup = (String) parent.getItemAtPosition(position);
                loadPackingList(selectedAgeGroup);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                selectedAgeGroup = null;
            }
        });
    }

    //Loads both coded and custom items for the age groups
    private void loadPackingList(String ageGroup)
    {
        List<PackingList> items = new ArrayList<>();

        if (predefinedPackingLists.containsKey(ageGroup))
        {
            for (String item : predefinedPackingLists.get(ageGroup))
            {
                items.add(new PackingList(ageGroup, item, "General"));
            }
        }

        //Adds the custom items form the repository
        repository.getPackingListByAgeGroup(ageGroup).observe(this, customItems ->
        {
            items.addAll(customItems);
            adapter.updatePackingList(items);
        });
    }

    //Adds the users item to the list, send a message and adds it to the display
    private void addCustomItem(String item)
    {
        PackingList newItem = new PackingList(selectedAgeGroup, item);
        repository.insertItem(newItem);
        loadPackingList(selectedAgeGroup);
        editTextNewItem.setText("");
        Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
    }
}
