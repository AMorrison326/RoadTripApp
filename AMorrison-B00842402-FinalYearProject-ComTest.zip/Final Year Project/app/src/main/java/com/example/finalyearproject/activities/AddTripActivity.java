package com.example.finalyearproject.activities;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.finalyearproject.R;
import com.example.finalyearproject.models.Trip;
import com.example.finalyearproject.viewmodel.TripViewModel;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


import java.util.*;
import java.util.concurrent.Executors;

public class AddTripActivity extends AppCompatActivity {

    // Constants for identifying which location field was selected
    private static final int REQUEST_CODE_START = 100;
    private static final int REQUEST_CODE_DESTINATION = 101;
    private static final int REQUEST_CODE_STOP = 200;

    // UI Elements / Trip data fields
    private TextView startLocationView, destinationView, startDateView, endDateView;
    private Spinner ageSpinner;
    private LinearLayout stopsContainer;
    private Button addStopButton, saveTripButton;
    private String selectedStartDate, selectedEndDate, startLocationName, destinationName;
    private EditText tripNameEditText, inputChildren, inputTeenagers, inputAdults, inputElderly;
    private List<String> stops = new ArrayList<>();
    private TripViewModel tripViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip);

        //PLaces API initilisation
        if (!Places.isInitialized())
        {
            Places.initialize(getApplicationContext(), getString(R.string.google_maps_key));
        }

        //Binfing UI components to the java variables
        tripNameEditText = findViewById(R.id.trip_name_input);
        startLocationView = findViewById(R.id.start_location_input);
        destinationView = findViewById(R.id.destination_input);
        startDateView = findViewById(R.id.start_date);
        endDateView = findViewById(R.id.end_date);
        stopsContainer = findViewById(R.id.stops_container);
        addStopButton = findViewById(R.id.add_stop_button);
        saveTripButton = findViewById(R.id.save_trip_button);
        inputChildren = findViewById(R.id.input_children);
        inputTeenagers = findViewById(R.id.input_teenagers);
        inputAdults = findViewById(R.id.input_adults);
        inputElderly = findViewById(R.id.input_elderly);


        tripViewModel = new ViewModelProvider(this).get(TripViewModel.class);

        //Listeners for add trip areas
        startLocationView.setOnClickListener(v -> launchAutocomplete(REQUEST_CODE_START));
        destinationView.setOnClickListener(v -> launchAutocomplete(REQUEST_CODE_DESTINATION));
        addStopButton.setOnClickListener(v -> launchAutocomplete(REQUEST_CODE_STOP));

        startDateView.setOnClickListener(v -> pickDate(true));
        endDateView.setOnClickListener(v -> pickDate(false));

        saveTripButton.setOnClickListener(v -> saveTrip());

        // Bottom navigation menu
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_add);
        bottomNav.setOnItemSelectedListener(item ->
        {
            int id = item.getItemId();
            if (id == R.id.nav_home) startActivity(new Intent(this, MainActivity.class));
            else if (id == R.id.nav_saved)
                startActivity(new Intent(this, SavedTripsActivity.class));
            else if (id == R.id.nav_packing)
                startActivity(new Intent(this, PackingListActivity.class));
            else if (id == R.id.nav_entertainment)
                startActivity(new Intent(this, EntertainmentActivity.class));
            return true;
        });
    }

    //Google places competion based on request types
    private void launchAutocomplete(int requestCode)
    {
        if (!isRunningTest())
        {
            List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);
            Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields).build(this);
            startActivityForResult(intent, requestCode);
        }
    }

    //Date picker launched and result stored
    private void pickDate(boolean isStartDate)
    {
        Calendar calendar = Calendar.getInstance();

        new DatePickerDialog(
                this,
                R.style.DateBoxTheme,
                (view, year, month, dayOfMonth) ->
                {
                    String date = dayOfMonth + "/" + (month + 1) + "/" + year;
                    if (isStartDate)
                    {
                        selectedStartDate = date;
                        startDateView.setText(date);
                    }
                    else
                    {
                        selectedEndDate = date;
                        endDateView.setText(date);
                    }
                }
                ,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        )
        .show();
    }

    //Location picker launched and result stored
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null)
        {
            Place place = Autocomplete.getPlaceFromIntent(data);
            if (requestCode == REQUEST_CODE_START)
            {
                startLocationName = place.getName();
                startLocationView.setText(startLocationName);
            }
            else if (requestCode == REQUEST_CODE_DESTINATION)
            {
                destinationName = place.getName();
                destinationView.setText(destinationName);
            }
            else if (requestCode == REQUEST_CODE_STOP)
            {
                String stopName = place.getName();
                stops.add(stopName);
                addStopView(stopName);
            }
        }
    }

    //Add a visual for additional stops
    private void addStopView(String stopName)
    {
        TextView stopView = new TextView(this);
        stopView.setText(stopName);
        stopView.setPadding(16, 8, 16, 8);
        stopsContainer.addView(stopView);
    }

    //Saves the trip to the room database using the viewmodel
    private void saveTrip()
    {
        String name = tripNameEditText.getText().toString().trim();


        if (name.isEmpty() || startLocationName == null || destinationName == null || selectedStartDate == null || selectedEndDate == null)
        {
            Toast.makeText(this, "Please complete all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int children = parseIntOrZero(inputChildren.getText().toString());
        int teenagers = parseIntOrZero(inputTeenagers.getText().toString());
        int adults = parseIntOrZero(inputAdults.getText().toString());
        int elderly = parseIntOrZero(inputElderly.getText().toString());

        if (children + teenagers + adults + elderly == 0)
        {
            Toast.makeText(this, "Please enter at least one passenger in any age group", Toast.LENGTH_SHORT).show();
            return;
        }


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null)
        {
            Toast.makeText(this, "You must be signed in to save a trip", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences("user_profile", MODE_PRIVATE);
        String fuelCost = prefs.getString("cost", "");


        //Creates the trip and inserts it
        Trip trip = new Trip(
                name,
                destinationName,
                selectedStartDate,
                selectedEndDate,
                startLocationName,
                children,
                teenagers,
                adults,
                elderly,
                user.getUid(),
                "",
                stops
        );

        Executors.newSingleThreadExecutor().execute(() -> {
            long tripId = tripViewModel.insertTripAndReturnId(trip);

            runOnUiThread(() -> {
                Toast.makeText(this, "Trip Saved!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, TripSummaryActivity.class);
                intent.putExtra("trip_id", (int) tripId);
                intent.putExtra("fuel_cost", fuelCost);
                startActivity(intent);
                finish();
            });
        });
    }


    //Parses input texts into an integer or will return a 0 if invalid.
    private int parseIntOrZero(String input)
    {
        try
        {
            input = input.trim();
            if (input.isEmpty()) return 0;
            return Integer.parseInt(input);
        }
        catch (NumberFormatException e)
        {
            return 0;
        }
    }

    //CHeck if testing is running to suppress UI components if required
    private boolean isRunningTest() {
        return "true".equals(System.getProperty("robolectric")) ||
                "true".equals(System.getProperty("IS_TESTING"));
    }
//
//    //Used by UI Tests to bypass the Google Places Autocomplete flow
//    public void setStartLocationName(String name) {
//        this.startLocationName = name;
//        if (startLocationView != null) {
//            startLocationView.setText(name);
//        }
//    }
//
//    public void setDestinationName(String name) {
//        this.destinationName = name;
//        if (destinationView != null) {
//            destinationView.setText(name);
//        }
//    }


    // Validation
    public boolean isTripNameValid(String name) {
        return name != null && !name.trim().isEmpty();
    }

    public boolean isPassengerCountValid(int children, int teens, int adults, int elderly) {
        return (children + teens + adults + elderly) > 0;
    }
}