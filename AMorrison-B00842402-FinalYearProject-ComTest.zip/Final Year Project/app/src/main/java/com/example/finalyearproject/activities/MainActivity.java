package com.example.finalyearproject.activities;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalyearproject.R;
import com.firebase.ui.auth.AuthUI;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.Picasso;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity
{

    private FirebaseAuth mAuth;
    private static final int RC_SIGN_IN = 123;

    //Buttons for navigating to the other pages
    private Button mapButton, packingListButton, savedTripButton, addTripButton, entertainmentButton;
    private ImageButton DataButton, userProfileButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        // Safe debug check without BuildConfig
        boolean isDebug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;

        //Firebase authentication initiation
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        //If the user is not signed in then the login screen is launched
        if (currentUser == null)
        {
            createSignInIntent();
            return;
        }

        //Loads the main screen if user is logged in
        setContentView(R.layout.activity_main);

        //Welcome toast messages
        boolean isFirstLaunch = getSharedPreferences("app_prefs", MODE_PRIVATE)
                .getBoolean("just_signed_in", false);

        if (isFirstLaunch)
        {
            Toast.makeText(this, "Signed in as: " + currentUser.getDisplayName(), Toast.LENGTH_SHORT).show();

            getSharedPreferences("app_prefs", MODE_PRIVATE)
                    .edit()
                    .putBoolean("just_signed_in", false)
                    .apply();
        }
        initializeUI();
    }

    //Sets up the UI buttons and the listeners
    private void initializeUI()
    {
        mapButton = findViewById(R.id.map_button);
        userProfileButton = findViewById(R.id.user_profile_button);
        packingListButton = findViewById(R.id.packing_list_button);
        savedTripButton = findViewById(R.id.saved_trips_button);
        DataButton = findViewById(R.id.settings_button);
        addTripButton = findViewById(R.id.add_trip_button);
        entertainmentButton = findViewById(R.id.entertainment_button);

        //Assigns the button clicks to navigate to the set activity
        mapButton.setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class)));
        userProfileButton.setOnClickListener(v -> startActivity(new Intent(this, UserProfileActivity.class)));
        packingListButton.setOnClickListener(v -> startActivity(new Intent(this, PackingListActivity.class)));
        savedTripButton.setOnClickListener(v -> startActivity(new Intent(this, SavedTripsActivity.class)));
        addTripButton.setOnClickListener(v -> startActivity(new Intent(this, AddTripActivity.class)));
        DataButton.setOnClickListener(v -> startActivity(new Intent(this, DataActivity.class)));
        entertainmentButton.setOnClickListener(v -> startActivity(new Intent(this, EntertainmentActivity.class)));

        //Sets up nav bar and relevant logic
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_home);

        bottomNav.setOnItemSelectedListener(item ->
        {
            int id = item.getItemId();
            if (id == R.id.nav_packing)
            {
                startActivity(new Intent(this, PackingListActivity.class));
            }
            else if (id == R.id.nav_add)
            {
                startActivity(new Intent(this, AddTripActivity.class));
            }
            else if (id == R.id.nav_saved)
            {
                startActivity(new Intent(this, SavedTripsActivity.class));
            }
            else if (id == R.id.nav_entertainment)
            {
                startActivity(new Intent(this, EntertainmentActivity.class));
            }
            return true;
        });

        // Load profile image or fallback image
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null && user.getPhotoUrl() != null)
        {
            Picasso.get()
                    .load(user.getPhotoUrl())
                    .placeholder(R.drawable.profile)
                    .error(R.drawable.profile)
                    .into(userProfileButton);
        }
        else
        {
            userProfileButton.setImageResource(R.drawable.profile);
        }
    }

    //Launches the firebase UI
    private void createSignInIntent()
    {
        List<AuthUI.IdpConfig> providers = Arrays.asList(
                new AuthUI.IdpConfig.EmailBuilder().build(),
                new AuthUI.IdpConfig.GoogleBuilder().build(),
                new AuthUI.IdpConfig.AnonymousBuilder().build()
        );

        Intent signInIntent = AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .setIsSmartLockEnabled(false)
                .setTheme(R.style.Theme_FinalYearProject)
                .setLogo(R.drawable.logo)
                .build();

        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    //Handles the result of the sign in process
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN)
        {
            FirebaseUser user = mAuth.getCurrentUser();
            if (user != null)
            {
                getSharedPreferences("app_prefs", MODE_PRIVATE)
                        .edit()
                        .putBoolean("just_signed_in", true)
                        .apply();

                recreate();
            }
            else
            {
                Toast.makeText(this, "Sign-in failed or cancelled.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
}
