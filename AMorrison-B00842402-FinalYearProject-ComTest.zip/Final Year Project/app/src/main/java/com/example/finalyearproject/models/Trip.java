package com.example.finalyearproject.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import androidx.room.TypeConverters;

import com.example.finalyearproject.utils.StopConverter;

import java.util.List;

@Entity(tableName = "trips")
@TypeConverters({StopConverter.class})
public class Trip {

    //Generates the unique trip ID
    @PrimaryKey(autoGenerate = true)
    private int id;

    //Core trip details
    private String name;
    private String destination;
    private String startDate;
    private String endDate;
    private String startLocation;
    private int children;
    private int teenagers;
    private int adults;
    private int elderly;
    private String userId;
    private String comments;

    private List<String> additionalStops;

    //Default constructor
    public Trip()
    {
    }

    //Constructor which creates a new trips with all necessary values
    public Trip(String name, String destination, String startDate, String endDate,
                String startLocation, int children, int teenagers, int adults, int elderly,
                String userId, String comments, List<String> additionalStops) {
        this.name = name;
        this.destination = destination;
        this.startDate = startDate;
        this.endDate = endDate;
        this.startLocation = startLocation;
        this.children = children;
        this.teenagers = teenagers;
        this.adults = adults;
        this.elderly = elderly;
        this.userId = userId;
        this.comments = comments;
        this.additionalStops = additionalStops;
    }

//Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartLocation() {
        return startLocation;
    }

    public void setStartLocation(String startLocation) {
        this.startLocation = startLocation;
    }

    public int getChildren() {
        return children;
    }

    public void setChildren(int children) {
        this.children = children;
    }

    public int getTeenagers() {
        return teenagers;
    }

    public void setTeenagers(int teenagers) {
        this.teenagers = teenagers;
    }

    public int getAdults() {
        return adults;
    }

    public void setAdults(int adults) {
        this.adults = adults;
    }

    public int getElderly() {
        return elderly;
    }

    public void setElderly(int elderly) {
        this.elderly = elderly;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<String> getAdditionalStops() {
        return additionalStops;
    }

    public void setAdditionalStops(List<String> additionalStops) {
        this.additionalStops = additionalStops;
    }
}
